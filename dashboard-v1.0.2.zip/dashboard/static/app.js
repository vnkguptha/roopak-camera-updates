console.log("Roopak Camera Dashboard Loaded");

// Future Features

// WiFi scan
// OTA Updates
// Camera restart confirmation
// Storage graphs
// Multi-camera support

function confirmRestartCamera() {

    return confirm(
        "Restart Camera Service?"
    );
}

function confirmRestartAll() {

    return confirm(
        "Restart All Services?"
    );
}

async function checkUpdates(){

    const res =
        await fetch("/check-update");

    const data =
        await res.json();

    document.getElementById(
        "currentVersion"
    ).innerText =
        data.current;

    document.getElementById(
        "latestVersion"
    ).innerText =
        data.latest;

    document.getElementById(
        "releaseNotes"
    ).innerText =
        data.notes;
}

async function installUpdate(){

    await fetch("/install-update");

    monitorUpdate();
}

function monitorUpdate(){

    const timer = setInterval(
        async ()=>{

            const res =
                await fetch(
                    "/update-status"
                );

            const data =
                await res.json();

            document.getElementById(
                "updateStatus"
            ).innerText =
                data.status;

            if(
                data.status.includes(
                    "Complete"
                )
            ){
                clearInterval(timer);
            }

        },1000
    );
}

