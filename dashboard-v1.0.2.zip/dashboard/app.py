from flask import Flask, render_template, redirect
import os
import socket
import subprocess
import shutil
from datetime import datetime
import json
import requests

app = Flask(__name__)

RECORDINGS_DIR = "/var/lib/motioneye"

# -------------------------------------------------
# Helpers
# -------------------------------------------------

def get_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "0.0.0.0"

def get_temp():
    try:
        out = subprocess.check_output(
            ["vcgencmd", "measure_temp"]
        ).decode()

        return out.replace("temp=","").replace("'C\n","°C")
    except:
        return "N/A"

def get_uptime():
    try:
        with open("/proc/uptime") as f:
            seconds = float(f.readline().split()[0])

        days = int(seconds // 86400)
        hours = int((seconds % 86400) // 3600)
        mins = int((seconds % 3600) // 60)

        return f"{days}d {hours}h {mins}m"

    except:
        return "N/A"

def get_storage():
    total, used, free = shutil.disk_usage("/")

    return {
        "total": round(total/(1024**3),1),
        "used": round(used/(1024**3),1),
        "free": round(free/(1024**3),1),
        "percent": round((used/total)*100)
    }

def service_status(service):

    try:
        result = subprocess.check_output(
            ["systemctl","is-active",service]
        ).decode().strip()

        return result

    except:
        return "unknown"

def get_recordings():

    files = []

    for root, dirs, filenames in os.walk(RECORDINGS_DIR):

        for f in filenames:

            if f.endswith(
                (".mkv",".mp4",".avi",".mov")
            ):

                path = os.path.join(root,f)

                files.append({
                    "name":f,
                    "size":round(
                        os.path.getsize(path)/(1024*1024),1
                    ),
                    "date":datetime.fromtimestamp(
                        os.path.getmtime(path)
                    ).strftime("%Y-%m-%d %H:%M")
                })

    files = sorted(
        files,
        key=lambda x:x["date"],
        reverse=True
    )

    return files[:20]

# -------------------------------------------------
# Dashboard
# -------------------------------------------------

@app.route("/")
@app.route("/live")
def dashboard():

    return render_template(
        "dashboard.html",
        page="live",
        ip=get_ip(),
        temp=get_temp(),
        uptime=get_uptime(),
        storage=get_storage(),
        total_recordings=len(get_recordings())
    )

# -------------------------------------------------
# Recordings
# -------------------------------------------------

@app.route("/recordings")
def recordings():

    return render_template(
        "recordings.html",
        page="recordings",
        recordings=get_recordings()
    )

# -------------------------------------------------
# Device Status
# -------------------------------------------------

@app.route("/status")
def status():

    return render_template(
        "status.html",
        page="status",

        mediamtx=service_status(
            "mediamtx.service"
        ),

        camera=service_status(
            "camera.service"
        ),

        dashboard=service_status(
            "roopak-dashboard.service"
        ),

        temperature=get_temp(),
        uptime=get_uptime(),
        storage=get_storage(),
        ip=get_ip()
    )

# -------------------------------------------------
# WiFi
# -------------------------------------------------

@app.route("/wifi")
def wifi():

    networks = []

    try:

        output = subprocess.check_output(
            ["nmcli","-t","-f","SSID,SIGNAL","dev","wifi"]
        ).decode()

        for line in output.splitlines():

            parts = line.split(":")

            if len(parts) >= 2:

                networks.append({
                    "name": parts[0],
                    "signal": parts[1] + "%"
                })

    except:
        pass

    return render_template(
        "wifi.html",
        page="wifi",
        networks=networks
    )
# -------------------------------------------------
# Updates
# -------------------------------------------------

@app.route("/updates")
def updates():

    return render_template(
        "updates.html",
        page="updates",
        version="1.0.0"
    )

# -------------------------------------------------
# Restart Camera
# -------------------------------------------------

@app.route("/restart-camera")
def restart_camera():

    os.system(
        "sudo systemctl restart camera.service"
    )

    return redirect("/")

# -------------------------------------------------
# Restart All
# -------------------------------------------------

@app.route("/restart-all")
def restart_all():

    os.system(
        "sudo systemctl restart camera.service"
    )

    os.system(
        "sudo systemctl restart mediamtx.service"
    )

    return redirect("/")

# -------------------------------------------------
@app.route("/check-update")
def check_update():

    local = json.load(
        open("/home/roopak/roopak-camera/version.json")
    )

    remote = requests.get(
        "https://raw.githubusercontent.com/vnkguptha/roopak-camera-updates/main/update.json"
    ).json()

    return {
        "current": local["version"],
        "latest": remote["version"],
        "notes": remote["release_notes"]
    }


@app.route("/install-update")
def install_update():

    subprocess.Popen(
        ["/home/roopak/roopak-camera/ota/install_update.sh"]
    )

    return {
        "status":"started"
    }

@app.route("/update-status")
def update_status():

    try:

        with open("/tmp/update_status.txt") as f:
            return {
                "status": f.read()
            }

    except:

        return {
            "status":"Idle"
        }

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000
    )
